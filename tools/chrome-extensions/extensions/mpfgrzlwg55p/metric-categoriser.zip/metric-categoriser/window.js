const BASE = 'https://app.hook.co/api';
const METRICS_TYPE = 'account_custom_metric_graph';

let token = null;
let customerSlug = null;
let categoriesMap = {};
let currentProductId = null;
let allMetrics = []; // full list after load, needed for push diff

// metricId -> { name, originalIds, getCurrentIds }
const pendingChanges = new Map();

const productSelect = document.getElementById('product-select');
const refreshBtn    = document.getElementById('refresh-btn');
const pushBtn       = document.getElementById('push-btn');
const metricCount   = document.getElementById('metric-count');
const banner        = document.getElementById('banner');
const emptyEl       = document.getElementById('empty');
const tableEl       = document.getElementById('table');
const tbody         = document.getElementById('tbody');

// ── Banner ────────────────────────────────────────────────────────────────────

function showBanner(msg, type = 'error') {
  banner.textContent = msg;
  banner.className = type;
  banner.style.display = '';
}

function clearBanner() {
  banner.textContent = '';
  banner.className = '';
  banner.style.display = 'none';
}

// ── Push button state ─────────────────────────────────────────────────────────

function updatePushBtn() {
  const count = pendingChanges.size;
  pushBtn.disabled = count === 0;
  pushBtn.textContent = count > 0 ? `Push ${count} Change${count !== 1 ? 's' : ''}` : 'Push Changes';
}

// ── API ───────────────────────────────────────────────────────────────────────

async function apiFetch(url, options = {}) {
  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    ...options,
  });
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`${res.status} ${res.statusText}${text ? ': ' + text : ''}`);
  }
  if (res.status === 204) return null;
  return res.json();
}

async function fetchAllMetrics(productId) {
  const items = [];
  let continuationToken = null;
  do {
    const url = new URL(`${BASE}/v0/customers/product-metrics/${METRICS_TYPE}/search`);
    url.searchParams.set('product_id', productId);
    if (continuationToken) url.searchParams.set('continuation_token', continuationToken);
    const data = await apiFetch(url.toString());
    items.push(...data.items);
    continuationToken = data.continuation_token;
  } while (continuationToken);
  return items;
}

async function fetchCategories(productId) {
  const data = await apiFetch(`${BASE}/v0/customers/product-metric-categories?product_id=${productId}`);
  return data.items.filter(c => c.deactivated_date === null);
}

// ── Push changes ──────────────────────────────────────────────────────────────

async function pushChanges() {
  if (!pendingChanges.size) return;

  pushBtn.disabled = true;
  pushBtn.textContent = 'Pushing...';
  clearBanner();

  // Build current categoryId -> Set<metricId> from loaded metrics
  const categoryMetrics = new Map();
  for (const metric of allMetrics) {
    for (const catId of metric.categories) {
      if (!categoryMetrics.has(catId)) categoryMetrics.set(catId, new Set());
      categoryMetrics.get(catId).add(metric.id);
    }
  }

  // Apply pending changes to find which categories need updating
  const affectedCategories = new Set();
  for (const [metricId, { getCurrentIds }] of pendingChanges) {
    const original = allMetrics.find(m => m.id === metricId);
    if (!original) continue;

    const oldIds = original.categories;
    const newIds = getCurrentIds();

    const added   = newIds.filter(id => !oldIds.includes(id));
    const removed = oldIds.filter(id => !newIds.includes(id));

    for (const catId of added) {
      if (!categoryMetrics.has(catId)) categoryMetrics.set(catId, new Set());
      categoryMetrics.get(catId).add(metricId);
      affectedCategories.add(catId);
    }
    for (const catId of removed) {
      categoryMetrics.get(catId)?.delete(metricId);
      affectedCategories.add(catId);
    }
  }

  // PUT each affected category with its new full metric list
  const errors = [];
  for (const catId of affectedCategories) {
    const metricIds = [...(categoryMetrics.get(catId) ?? [])];
    try {
      await apiFetch(`${BASE}/v0/customers/product-metric-categories/${catId}/metrics`, {
        method: 'PUT',
        body: JSON.stringify({ metrics: metricIds }),
      });
    } catch (err) {
      const catName = categoriesMap[catId] ?? `#${catId}`;
      errors.push(`"${catName}": ${err.message}`);
    }
  }

  if (errors.length) {
    showBanner(`${errors.length} update(s) failed: ${errors.join(' | ')}`);
  }

  await loadProduct(currentProductId);
}

// ── Multi-select ──────────────────────────────────────────────────────────────

function buildMultiSelect(allCategories, selectedIds, onChange) {
  const wrap = document.createElement('div');
  wrap.className = 'ms-wrap';

  const trigger = document.createElement('div');
  trigger.className = 'ms-trigger';

  const dropdown = document.createElement('div');
  dropdown.className = 'ms-dropdown';

  dropdown.addEventListener('click', e => e.stopPropagation());

  function getChecked() {
    return [...dropdown.querySelectorAll('input:checked')].map(cb => Number(cb.value));
  }

  function updateTriggerLabel() {
    const checked = [...dropdown.querySelectorAll('input:checked')];
    trigger.textContent = checked.length
      ? checked.map(cb => cb.dataset.name).join(', ')
      : '— none —';
  }

  if (allCategories.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'ms-empty';
    empty.textContent = 'No categories';
    dropdown.appendChild(empty);
  } else {
    allCategories.forEach(cat => {
      const row = document.createElement('label');
      row.className = 'ms-option';

      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.value = cat.id;
      cb.dataset.name = cat.name;
      cb.checked = selectedIds.includes(cat.id);

      cb.addEventListener('change', () => {
        updateTriggerLabel();
        onChange(getChecked());
      });

      row.append(cb, document.createTextNode(cat.name));
      dropdown.appendChild(row);
    });
  }

  updateTriggerLabel();

  trigger.addEventListener('click', e => {
    e.stopPropagation();
    const isOpen = dropdown.classList.contains('open');
    closeAllDropdowns();
    if (!isOpen) {
      dropdown.classList.add('open');
      trigger.classList.add('open');
    }
  });

  wrap.append(trigger, dropdown);
  wrap.getCurrentIds = getChecked;
  return wrap;
}

function closeAllDropdowns() {
  document.querySelectorAll('.ms-dropdown.open').forEach(d => d.classList.remove('open'));
  document.querySelectorAll('.ms-trigger.open').forEach(t => t.classList.remove('open'));
}

document.addEventListener('click', closeAllDropdowns);

// ── Table ─────────────────────────────────────────────────────────────────────

function arraysEqual(a, b) {
  return a.length === b.length && a.every((v, i) => v === b[i]);
}

function renderTable(metrics, activeCategories) {
  tbody.innerHTML = '';
  pendingChanges.clear();
  updatePushBtn();

  if (!metrics.length) {
    tableEl.style.display = 'none';
    emptyEl.style.display = 'block';
    emptyEl.textContent = 'No metrics found for this product.';
    metricCount.textContent = '';
    return;
  }

  metricCount.textContent = `${metrics.length} metric${metrics.length !== 1 ? 's' : ''}`;
  emptyEl.style.display = 'none';
  tableEl.style.display = 'table';

  metrics.forEach(metric => {
    const tr = document.createElement('tr');
    const originalIds = [...metric.categories].sort((a, b) => a - b);

    const nameTd = document.createElement('td');
    nameTd.className = 'metric-name';
    nameTd.textContent = metric.name;

    const keyTd = document.createElement('td');
    keyTd.className = 'metric-key';
    keyTd.textContent = metric.key;

    const currentTd = document.createElement('td');
    if (metric.categories.length) {
      metric.categories.forEach(id => {
        const tag = document.createElement('span');
        tag.className = 'tag';
        tag.textContent = categoriesMap[id] ?? `#${id}`;
        currentTd.appendChild(tag);
      });
    } else {
      const tag = document.createElement('span');
      tag.className = 'tag none';
      tag.textContent = 'none';
      currentTd.appendChild(tag);
    }

    const assignTd = document.createElement('td');
    const ms = buildMultiSelect(activeCategories, metric.categories, (newIds) => {
      const sorted = [...newIds].sort((a, b) => a - b);
      const changed = !arraysEqual(sorted, originalIds);
      tr.classList.toggle('changed', changed);

      if (changed) {
        pendingChanges.set(metric.id, { getCurrentIds: () => ms.getCurrentIds() });
      } else {
        pendingChanges.delete(metric.id);
      }
      updatePushBtn();
    });

    assignTd.appendChild(ms);
    tr.append(nameTd, keyTd, currentTd, assignTd);
    tbody.appendChild(tr);
  });
}

// ── Load product ──────────────────────────────────────────────────────────────

async function loadProduct(productId) {
  tableEl.style.display = 'none';
  emptyEl.style.display = 'block';
  emptyEl.textContent = 'Loading...';
  metricCount.textContent = '';
  refreshBtn.disabled = true;
  clearBanner();

  try {
    const [metrics, categories] = await Promise.all([
      fetchAllMetrics(productId),
      fetchCategories(productId),
    ]);
    allMetrics = metrics;
    categoriesMap = Object.fromEntries(categories.map(c => [c.id, c.name]));
    renderTable(metrics, categories);
  } catch (err) {
    showBanner(`Failed to load data: ${err.message}`);
    emptyEl.textContent = 'Error loading data.';
    emptyEl.style.display = 'block';
    tableEl.style.display = 'none';
  } finally {
    refreshBtn.disabled = false;
  }
}

// ── Init ──────────────────────────────────────────────────────────────────────

productSelect.addEventListener('change', () => {
  if (!productSelect.value) return;
  currentProductId = productSelect.value;
  loadProduct(currentProductId);
});

refreshBtn.addEventListener('click', () => {
  if (currentProductId) loadProduct(currentProductId);
});

pushBtn.addEventListener('click', pushChanges);

async function init() {
  const cookie = await chrome.cookies.get({ url: 'https://app.hook.co', name: 'access_token' });
  if (!cookie) {
    showBanner('No access_token cookie found. Please log in to app.hook.co first.');
    return;
  }

  token = cookie.value;

  try {
    const payload = JSON.parse(atob(token.split('.')[1]));
    customerSlug = payload.cid;
  } catch {
    showBanner('Could not decode token. Try logging out and back in.');
    return;
  }

  try {
    const data = await apiFetch(`${BASE}/v1/customers/${customerSlug}/products/`);
    productSelect.innerHTML = '';
    const placeholder = document.createElement('option');
    placeholder.value = '';
    placeholder.textContent = 'Select a product…';
    productSelect.appendChild(placeholder);
    data.items.forEach(p => {
      const opt = document.createElement('option');
      opt.value = p.id;
      opt.textContent = p.name;
      productSelect.appendChild(opt);
    });
    productSelect.disabled = false;
  } catch (err) {
    showBanner(`Failed to load products: ${err.message}`);
  }
}

init();
