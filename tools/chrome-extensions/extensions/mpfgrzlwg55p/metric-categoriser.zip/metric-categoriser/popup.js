const statusEl = document.getElementById('status');
const tokenBox = document.getElementById('token-box');
const copyBtn = document.getElementById('copy-btn');
const openBtn = document.getElementById('open-btn');

async function init() {
  const cookie = await chrome.cookies.get({ url: 'https://app.hook.co', name: 'access_token' });

  if (!cookie) {
    statusEl.textContent = 'Not logged in to app.hook.co';
    statusEl.className = 'error';
    return;
  }

  statusEl.textContent = 'Token found — ready.';
  statusEl.className = 'success';
  tokenBox.textContent = cookie.value;
  tokenBox.style.display = 'block';
  copyBtn.style.display = 'block';
  openBtn.disabled = false;
}

copyBtn.addEventListener('click', async () => {
  await navigator.clipboard.writeText(tokenBox.textContent);
  copyBtn.textContent = 'Copied!';
  setTimeout(() => { copyBtn.textContent = 'Copy Token'; }, 1500);
});

openBtn.addEventListener('click', () => {
  chrome.windows.create({
    url: chrome.runtime.getURL('window.html'),
    type: 'popup',
    width: 1000,
    height: 680,
  });
});

init();
