// Background service worker: relays the extension command to the active tab
chrome.commands.onCommand.addListener((command) => {
  if(command === 'logout-hook'){
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
      if(!tabs || !tabs[0]) return;
      const tab = tabs[0];
      if(!tab.url || !tab.url.startsWith('https://app.hook.co')) return;
      chrome.tabs.sendMessage(tab.id, {type: 'trigger-logout'}, () => {});
    });
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'getEmail') {
        chrome.identity.getProfileUserInfo((userInfo) => {
            sendResponse({ email: userInfo.email });
        });
        return true; // Keep message channel open for async response
    }
});