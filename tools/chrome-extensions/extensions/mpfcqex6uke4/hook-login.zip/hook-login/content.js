let hasFilledEmail = false;
let hasClickedAccount = false;

// Logout functionality from login-switcher
function isEditable(el){
    if(!el) return false;
    try{
        if(el.isContentEditable) return true;
    }catch(e){}
    const tag = el.tagName || '';
    if(['INPUT','TEXTAREA','SELECT'].includes(tag)) return true;
    if(el.closest && el.closest('[contenteditable="true"]')) return true;
    return false;
}

function findLogoutButton(){
    // Prefer exact-match button text
    const buttons = Array.from(document.querySelectorAll('button'));
    for(const b of buttons){
        if((b.textContent||'').trim() === 'Logout') return b;
    }
    // Look for elements that mention Logout
    const els = Array.from(document.querySelectorAll('button, a'));
    for(const e of els){
        if((e.textContent||'').trim().toLowerCase().includes('logout')) return e;
    }
    return null;
}

function doLogout(){
    const btn = findLogoutButton();
    if(btn){
        btn.click();
        // Refresh page after logout
        setTimeout(() => {
            window.location.reload();
        }, 100);
        return true;
    }
    // Fallback: POST to logout endpoint
    try{
        fetch('/api/v0/logout', {method:'POST', credentials:'same-origin'}).then(() => {
            setTimeout(() => {
                window.location.reload();
            }, 500);
        }).catch(()=>{});
        return true;
    }catch(e){
        return false;
    }
}

// Listen for L keydown (without Cmd modifier)
window.addEventListener('keydown', function(e) {
    if(e.defaultPrevented) return;
    const key = (e.key || '').toLowerCase();
    if(key === 'l'){
        if(isEditable(document.activeElement)) return;
        doLogout();
    }
}, true);

// Listen for background command messages
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if(msg && msg.type === 'trigger-logout'){
        if(isEditable(document.activeElement)) return sendResponse({ok:false, reason:'editable'});
        const ok = doLogout();
        sendResponse({ok});
    }
});

// Auto-login functionality
function fillEmailAndSubmit() {
    if (hasFilledEmail) return;
    
    const emailInput = document.querySelector('input[placeholder="Enter your email to continue..."]');
    
    if (emailInput && !emailInput.value) {
        hasFilledEmail = true;
        chrome.runtime.sendMessage({ action: 'getEmail' }, (response) => {
            if (response && response.email) {
                emailInput.value = response.email;
                emailInput.dispatchEvent(new Event('input', { bubbles: true }));
                emailInput.dispatchEvent(new Event('change', { bubbles: true }));
                
                setTimeout(() => {
                    const submitButton = document.querySelector('button[type="submit"]') ||
                                       document.querySelector('button:not([type="button"])') ||
                                       document.querySelector('form button');
                    
                    if (submitButton) {
                        submitButton.click();
                    } else {
                        const form = emailInput.closest('form');
                        if (form) {
                            form.submit();
                        }
                    }
                }, 200);
            }
        });
    }
}

function clickGoogleAccount() {
    if (hasClickedAccount) return;
    
    chrome.runtime.sendMessage({ action: 'getEmail' }, (response) => {
        if (response && response.email) {
            const accountDivs = document.querySelectorAll('[data-identifier], div[role="button"]');
            
            for (let div of accountDivs) {
                if (div.textContent.includes(response.email)) {
                    hasClickedAccount = true;
                    div.click();
                    break;
                }
            }
        }
    });
}

if (window.location.href.includes('app.hook.co/login')) {
    fillEmailAndSubmit();
    if (document.body) {
        const observer = new MutationObserver(fillEmailAndSubmit);
        observer.observe(document.body, { childList: true, subtree: true });
    }
} else if (window.location.href.includes('accounts.google.com')) {
    // Try immediately, then use observer to catch it when it loads
    setTimeout(() => {
        clickGoogleAccount();
    }, 50); // tiny buffer for initial load
    
    if (document.body) {
        let observerTriggered = false;
        const observer = new MutationObserver(() => {
            // Only trigger once, and add a small delay after DOM changes
            if (!observerTriggered && !hasClickedAccount) {
                observerTriggered = true;
                setTimeout(clickGoogleAccount, 50);
            }
        });
        observer.observe(document.body, { childList: true, subtree: true });
    }
}