chrome.identity.getProfileUserInfo((userInfo) => {
    document.getElementById('email').textContent = userInfo.email || 'No email found';
});