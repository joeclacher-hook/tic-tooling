(function () {
  function formatKey(key) {
    let s = key;
    s = s.replace(/_pct_change/gi, '_PCT_CHANGE');
    s = s.replace(/_pct/gi, '_PCT');
    s = s.replace(/_/g, ' ');
    s = s.replace(/([a-z])([A-Z])/g, '$1 $2');
    s = s.split(/\s+/)
      .filter(w => w.length > 0)
      .map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
      .join(' ');
    s = s.replace(/Pct Change/g, '% Change');
    s = s.replace(/Pct/g, '%');
    return s.trim();
  }

  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  function setReactInputValue(input, value) {
    const nativeSetter = Object.getOwnPropertyDescriptor(
      window.HTMLInputElement.prototype,
      'value'
    ).set;
    nativeSetter.call(input, value);
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }

  // Find a row by matching its key span text
  function findRowByKey(key) {
    for (const row of document.querySelectorAll('table tbody tr')) {
      const keySpan = row.querySelector('.text-xxs');
      if (!keySpan) continue;
      const rowKey = keySpan.textContent.replace(/Key:\s*/i, '').trim();
      if (rowKey === key) return row;
    }
    return null;
  }

  // Get the current display name (text node before <br> in the name cell)
  function getDisplayName(row) {
    const innerGrow = row.querySelector('td:first-child .flex.items-center .grow');
    if (!innerGrow) return '';
    for (const node of innerGrow.childNodes) {
      if (node.nodeType === Node.TEXT_NODE && node.textContent.trim()) {
        return node.textContent.trim();
      }
    }
    return '';
  }

  // Wait for the inline <form> to appear inside the row's first cell
  function waitForInlineForm(row, timeout = 3000) {
    return new Promise((resolve, reject) => {
      const existing = row.querySelector('td:first-child form');
      if (existing) return resolve(existing);

      const observer = new MutationObserver(() => {
        const found = row.querySelector('td:first-child form');
        if (found) {
          observer.disconnect();
          resolve(found);
        }
      });
      observer.observe(row, { childList: true, subtree: true });
      setTimeout(() => {
        observer.disconnect();
        reject(new Error('Timed out waiting for inline form'));
      }, timeout);
    });
  }

  // Wait for the inline form to disappear (save completed / re-render done)
  // Watch the whole tbody in case React replaces the row element entirely
  function waitForFormGone(tbody, timeout = 5000) {
    return new Promise((resolve) => {
      function isGone() {
        return !tbody.querySelector('td:first-child form');
      }
      if (isGone()) return resolve();

      const observer = new MutationObserver(() => {
        if (isGone()) {
          observer.disconnect();
          resolve();
        }
      });
      observer.observe(tbody, { childList: true, subtree: true });
      setTimeout(() => {
        observer.disconnect();
        resolve();
      }, timeout);
    });
  }

  function collectKeys() {
    const keys = [];
    for (const row of document.querySelectorAll('table tbody tr')) {
      const keySpan = row.querySelector('.text-xxs');
      if (!keySpan) continue;
      const key = keySpan.textContent.replace(/Key:\s*/i, '').trim();
      if (key) keys.push(key);
    }
    return keys;
  }

  async function processKey(key, settings, onProgress) {
    const formattedName = formatKey(key);

    const row = findRowByKey(key);
    if (!row) {
      onProgress(`  ⚠ Row not found for ${key} — skipping`);
      return;
    }

    const editBtn = row.querySelector('button[aria-label="Edit"]');
    if (!editBtn) {
      onProgress(`  ⚠ Edit button not found for ${key} — skipping`);
      return;
    }

    const tbody = row.closest('tbody');

    // Skip rename if already correct
    const currentName = getDisplayName(row);
    if (currentName === formattedName) {
      onProgress(`⏭ Already named: "${formattedName}"`);
    } else {
      row.scrollIntoView({ block: 'center' });
      await sleep(150);
      onProgress(`▶ ${key} → "${formattedName}"`);

      editBtn.click();

      let form;
      try {
        form = await waitForInlineForm(row, 3000);
      } catch {
        onProgress(`  ❌ Inline form didn't appear — skipping ${key}`);
        return;
      }
      await sleep(100);

      const input = form.querySelector('input[type="text"]');
      if (input) {
        input.focus();
        setReactInputValue(input, formattedName);
        await sleep(100);
      } else {
        onProgress(`  ⚠ Text input not found for ${key}`);
      }

      // Click the tick (submit) button
      const submitBtn = form.querySelector('button[type="submit"]');
      if (!submitBtn) {
        // Cancel and bail
        const cancelBtn = form.querySelector('button[type="button"]');
        if (cancelBtn) cancelBtn.click();
        onProgress(`  ❌ No submit button for ${key}`);
        return;
      }

      submitBtn.click();
      await waitForFormGone(tbody, 5000);
      await sleep(300);
      onProgress(`  ✓ "${formattedName}"`);
    }

    // Enable Customer table toggle if requested — re-find row after re-render
    if (settings.enableCustomerTable) {
      const freshRow = findRowByKey(key);
      if (freshRow) {
        const sw = freshRow.querySelector('button[role="switch"][aria-label="Table"]');
        if (sw && sw.getAttribute('aria-checked') !== 'true') {
          freshRow.scrollIntoView({ block: 'center' });
          await sleep(100);
          sw.click();
          await sleep(200);
          onProgress(`  ✓ Customer table enabled`);
        }
      }
    }
  }

  async function scrollToLoadAll(onProgress) {
    onProgress('Scrolling to load all rows…');
    const scroller = document.scrollingElement || document.documentElement;
    const step = Math.max(window.innerHeight * 0.8, 400);
    let lastRowCount = 0;
    let stableRounds = 0;

    while (stableRounds < 3) {
      scroller.scrollTop += step;
      await sleep(400);
      const currentCount = document.querySelectorAll('table tbody tr').length;
      if (currentCount === lastRowCount) {
        stableRounds++;
      } else {
        stableRounds = 0;
        lastRowCount = currentCount;
      }
    }

    scroller.scrollTop = 0;
    await sleep(300);
    onProgress(`Scroll complete. ${document.querySelectorAll('table tbody tr').length} rows found.`);
  }

  async function runAutomation(settings, onProgress) {
    await scrollToLoadAll(onProgress);

    const keys = collectKeys();
    if (keys.length === 0) {
      onProgress('❌ No custom field rows found on this page.');
      return;
    }

    onProgress(`Processing ${keys.length} custom field(s)…`);

    for (const key of keys) {
      await processKey(key, settings, onProgress);
    }

    onProgress('✅ All done!');
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.action === 'START') {
      const settings = {
        enableCustomerTable: msg.enableCustomerTable !== false,
      };
      runAutomation(settings, text => {
        chrome.runtime.sendMessage({ action: 'PROGRESS', text }).catch(() => {});
      })
        .then(() => sendResponse({ done: true }))
        .catch(err => sendResponse({ error: err.message }));
      return true;
    }
  });
})();
