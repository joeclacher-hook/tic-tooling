// panel.js

let allProcessors = [];
let selectedDate = null;          // { day, month, year }
let calViewDate = { year: new Date().getFullYear(), month: new Date().getMonth() + 1 };
let isRunning = false;
let msgListener = null;
const progressItems = {};         // name → DOM element

const MONTH_NAMES = ['January','February','March','April','May','June',
                     'July','August','September','October','November','December'];
const DAY_SHORT   = ['Su','Mo','Tu','We','Th','Fr','Sa'];

// ── DOM refs ──────────────────────────────────────────────
const patternEl       = document.getElementById('pattern');
const matchCountEl    = document.getElementById('match-count');
const setNullEl       = document.getElementById('set-null');
const nullRowEl       = document.getElementById('null-row');
const dateSectionEl   = document.getElementById('date-section');
const dateInputEl     = document.getElementById('date-input');
const calToggleEl     = document.getElementById('cal-toggle');
const calendarEl      = document.getElementById('calendar');
const runBtnEl        = document.getElementById('run-btn');
const errorEl         = document.getElementById('error-msg');
const progressSection = document.getElementById('progress-section');
const progressListEl  = document.getElementById('progress-list');
const progressSumEl   = document.getElementById('progress-summary');

// ── Init ─────────────────────────────────────────────────
async function init() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => Array.from(document.querySelectorAll('table tbody tr'))
               .map(r => r.querySelector('td:first-child')?.textContent.trim())
               .filter(Boolean)
    });
    allProcessors = results[0]?.result ?? [];
    refreshCount();
  } catch (e) {
    showError('Cannot read this page — make sure you are on the Processors page.');
  }
}

// ── Pattern matching ──────────────────────────────────────
function wildcardToRegex(pattern) {
  const escaped = pattern.replace(/[.+^${}()|[\]\\]/g, '\\$&');
  return new RegExp('^' + escaped.replace(/\*/g, '.*').replace(/\?/g, '.') + '$', 'i');
}

function getMatches() {
  const p = patternEl.value.trim();
  if (!p) return [];
  try {
    const re = wildcardToRegex(p);
    return allProcessors.filter(n => re.test(n));
  } catch { return []; }
}

function refreshCount() {
  const matches = getMatches();
  const p = patternEl.value.trim();
  if (p) {
    matchCountEl.textContent = matches.length;
    matchCountEl.className   = 'badge' + (matches.length === 0 ? ' zero' : '');
    matchCountEl.classList.remove('hidden');
  } else {
    matchCountEl.classList.add('hidden');
  }
  refreshRunBtn(matches);
}

patternEl.addEventListener('input', refreshCount);

// ── Set to NULL toggle ────────────────────────────────────
setNullEl.addEventListener('change', () => {
  const on = setNullEl.checked;
  nullRowEl.classList.toggle('active', on);
  dateInputEl.disabled  = on;
  calToggleEl.disabled  = on;
  if (on) calendarEl.classList.add('hidden');
  refreshRunBtn();
});
nullRowEl.addEventListener('click', (e) => {
  if (e.target === setNullEl) return; // avoid double-toggle
});

// ── Date text input ───────────────────────────────────────
dateInputEl.addEventListener('keydown', (e) => {
  if (['Backspace','Delete','ArrowLeft','ArrowRight','Tab'].includes(e.key)) return;
  if (!/^\d$/.test(e.key)) e.preventDefault();
});

dateInputEl.addEventListener('input', () => {
  const raw = dateInputEl.value.replace(/\D/g, '').slice(0, 8);
  let fmt = raw;
  if (raw.length > 4) fmt = raw.slice(0,2) + '-' + raw.slice(2,4) + '-' + raw.slice(4);
  else if (raw.length > 2) fmt = raw.slice(0,2) + '-' + raw.slice(2);

  if (dateInputEl.value !== fmt) dateInputEl.value = fmt;

  selectedDate = parseDate(fmt);
  if (selectedDate) {
    calViewDate = { year: selectedDate.year, month: selectedDate.month };
    if (!calendarEl.classList.contains('hidden')) renderCalendar();
  }
  refreshRunBtn();
});

function parseDate(s) {
  const m = s.match(/^(\d{2})-(\d{2})-(\d{4})$/);
  if (!m) return null;
  const d = +m[1], mo = +m[2], y = +m[3];
  if (mo < 1 || mo > 12 || d < 1) return null;
  if (d > new Date(y, mo, 0).getDate()) return null; // new Date(y,mo,0) = last day of month mo
  return { day: d, month: mo, year: y };
}

// ── Calendar widget ───────────────────────────────────────
calToggleEl.addEventListener('click', () => {
  if (calendarEl.classList.contains('hidden')) {
    if (!selectedDate) {
      const n = new Date();
      calViewDate = { year: n.getFullYear(), month: n.getMonth() + 1 };
    }
    renderCalendar();
    calendarEl.classList.remove('hidden');
  } else {
    calendarEl.classList.add('hidden');
  }
});

function renderCalendar() {
  const { year, month } = calViewDate;
  const today = new Date(); today.setHours(0,0,0,0);

  const firstDow    = new Date(year, month - 1, 1).getDay();
  const daysInMonth = new Date(year, month, 0).getDate();
  const daysInPrev  = new Date(year, month - 1, 0).getDate();

  const nextMonthStart = new Date(year, month, 1);
  const canNext = nextMonthStart <= today;

  let html = `
    <div class="cal-header">
      <button class="cal-nav" id="cp">&#8249;</button>
      <span class="cal-month-label">${MONTH_NAMES[month-1]} ${year}</span>
      <button class="cal-nav" id="cn" ${!canNext ? 'disabled' : ''}>&#8250;</button>
    </div>
    <div class="cal-grid">
      <div class="cal-weekdays">${DAY_SHORT.map(d => `<span>${d}</span>`).join('')}</div>
      <div class="cal-days">`;

  // Trailing days from prev month
  for (let i = firstDow - 1; i >= 0; i--)
    html += `<span class="cal-day other-month">${daysInPrev - i}</span>`;

  // Current month
  for (let d = 1; d <= daysInMonth; d++) {
    const dt = new Date(year, month - 1, d);
    const future  = dt > today;
    const isToday = dt.getTime() === today.getTime();
    const isSel   = selectedDate && selectedDate.day === d &&
                    selectedDate.month === month && selectedDate.year === year;
    let cls = 'cal-day';
    if (isSel)   cls += ' selected';
    if (isToday) cls += ' today';
    html += `<button class="${cls}" data-d="${d}" ${future ? 'disabled' : ''}>${d}</button>`;
  }

  // Filler
  const total = Math.ceil((firstDow + daysInMonth) / 7) * 7;
  for (let d = 1; d <= total - firstDow - daysInMonth; d++)
    html += `<span class="cal-day other-month">${d}</span>`;

  html += `</div></div>`;
  calendarEl.innerHTML = html;

  document.getElementById('cp').addEventListener('click', () => {
    calViewDate.month--;
    if (calViewDate.month < 1) { calViewDate.month = 12; calViewDate.year--; }
    renderCalendar();
  });

  document.getElementById('cn').addEventListener('click', () => {
    calViewDate.month++;
    if (calViewDate.month > 12) { calViewDate.month = 1; calViewDate.year++; }
    renderCalendar();
  });

  calendarEl.querySelectorAll('.cal-day[data-d]').forEach(btn => {
    btn.addEventListener('click', () => {
      const d = +btn.dataset.d;
      selectedDate = { day: d, month: calViewDate.month, year: calViewDate.year };
      dateInputEl.value = `${pad(d)}-${pad(calViewDate.month)}-${calViewDate.year}`;
      calendarEl.classList.add('hidden');
      refreshRunBtn();
    });
  });
}

function pad(n) { return String(n).padStart(2, '0'); }

// ── Run button state ──────────────────────────────────────
function refreshRunBtn(matches) {
  if (isRunning) return;
  const m = matches ?? getMatches();
  const hasDate = setNullEl.checked || selectedDate !== null;
  runBtnEl.disabled = !(m.length > 0 && hasDate);
  runBtnEl.textContent = m.length > 0
    ? `Run on ${m.length} processor${m.length !== 1 ? 's' : ''}`
    : 'Run (no matches)';
}

// ── Progress UI ───────────────────────────────────────────
function setupProgress(processors) {
  progressSection.classList.remove('hidden');
  progressListEl.innerHTML = '';
  progressSumEl.textContent = '';
  Object.keys(progressItems).forEach(k => delete progressItems[k]);

  processors.forEach(name => {
    const el = document.createElement('div');
    el.className = 'progress-item';
    el.innerHTML = `<div class="status-dot status-pending"></div>
                    <div class="pname" title="${name}">${name}</div>`;
    progressListEl.appendChild(el);
    progressItems[name] = el;
  });
}

function onProgress(msg) {
  if (msg.type === 'AUTOMATION_PROGRESS') {
    const el = progressItems[msg.processorName];
    if (!el) return;
    el.querySelector('.status-dot').className = `status-dot status-${msg.status}`;
    if (msg.error) {
      const span = document.createElement('span');
      span.className = 'item-err';
      span.title = msg.error;
      span.textContent = msg.error;
      el.appendChild(span);
    }
    if (msg.status === 'running') el.scrollIntoView({ block: 'nearest' });

  } else if (msg.type === 'AUTOMATION_DONE') {
    progressSumEl.textContent = `Done — ${msg.processed} succeeded, ${msg.failed} failed`;
    isRunning = false;
    if (msgListener) { chrome.runtime.onMessage.removeListener(msgListener); msgListener = null; }
    runBtnEl.disabled = false;
    runBtnEl.textContent = 'Run Again';
  }
}

// ── Run ───────────────────────────────────────────────────
runBtnEl.addEventListener('click', async () => {
  if (isRunning) return;
  const matches = getMatches();
  if (!matches.length) return;
  const isNull = setNullEl.checked;
  if (!isNull && !selectedDate) return;

  isRunning = true;
  hideError();
  runBtnEl.disabled = true;
  runBtnEl.textContent = 'Running…';

  setupProgress(matches);

  // Register listener BEFORE executeScript so no messages are missed
  msgListener = onProgress;
  chrome.runtime.onMessage.addListener(msgListener);

  const config = { processors: matches, setToNull: isNull, date: selectedDate };

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    // executeScript resolves after the function returns, but the async IIFE inside
    // continues running and sends messages back via chrome.runtime.sendMessage
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: pageAutomation,
      args: [config]
    });
  } catch (e) {
    showError('Failed to inject automation: ' + e.message);
    isRunning = false;
    chrome.runtime.onMessage.removeListener(msgListener);
    msgListener = null;
    refreshRunBtn();
  }
});

// ── Error helpers ─────────────────────────────────────────
function showError(msg) { errorEl.textContent = msg; errorEl.classList.remove('hidden'); }
function hideError()    { errorEl.classList.add('hidden'); }

// ─────────────────────────────────────────────────────────
// Automation function — serialised and injected into the page
// IMPORTANT: must be fully self-contained (no outer-scope references)
// ─────────────────────────────────────────────────────────
function pageAutomation(config) {
  const { processors, setToNull, date } = config;

  const MONTHS = ['January','February','March','April','May','June',
                  'July','August','September','October','November','December'];

  const send  = d => { try { chrome.runtime.sendMessage(d); } catch(_) {} };
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  function waitFor(selector, root, timeout) {
    root    = root    || document;
    timeout = timeout || 6000;
    return new Promise((res, rej) => {
      const end = Date.now() + timeout;
      (function poll() {
        const el = root.querySelector(selector);
        if (el) return res(el);
        if (Date.now() > end) return rej(new Error('Timeout waiting for: ' + selector));
        setTimeout(poll, 80);
      })();
    });
  }

  function waitGone(selector, timeout) {
    timeout = timeout || 10000;
    return new Promise((res, rej) => {
      const end = Date.now() + timeout;
      (function poll() {
        if (!document.querySelector(selector)) return res();
        if (Date.now() > end) return rej(new Error('Still visible after timeout: ' + selector));
        setTimeout(poll, 80);
      })();
    });
  }

  // React-compatible value setter
  function setVal(input, value) {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
    setter.call(input, value);
    input.dispatchEvent(new Event('input',  { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }

  async function navToMonth(dialog, targetYear, targetMonth) {
    for (let i = 0; i < 36; i++) {
      // Use the grid's aria-label which is "Month YYYY" — more stable than CSS class names
      const grid = dialog.querySelector('table[role="grid"]');
      if (!grid) throw new Error('Calendar grid not found in dialog');
      const parts = (grid.getAttribute('aria-label') || '').split(' ');
      const curMonth = MONTHS.indexOf(parts[0]) + 1;
      const curYear  = parseInt(parts[1]);

      if (curYear === targetYear && curMonth === targetMonth) return;

      const goBack = curYear > targetYear || (curYear === targetYear && curMonth > targetMonth);
      const label  = goBack ? 'Go to the Previous Month' : 'Go to the Next Month';
      const nav    = dialog.querySelector('nav[aria-label="Navigation bar"]');
      if (!nav) throw new Error('Navigation bar not found');
      const btn = nav.querySelector(`button[aria-label="${label}"]`);
      if (!btn || btn.disabled || btn.getAttribute('aria-disabled') === 'true')
        throw new Error(`Cannot navigate: "${label}" button is unavailable`);
      btn.click();
      await sleep(280);
    }
    throw new Error('Could not reach target month after 36 steps');
  }

  async function processOne(name) {
    // Find row by exact processor name
    const row = Array.from(document.querySelectorAll('table tbody tr'))
      .find(r => r.querySelector('td:first-child')?.textContent.trim() === name);
    if (!row) throw new Error('Row not found for: ' + name);

    const calBtn = row.querySelector('button[aria-label="Edit date"]');
    if (!calBtn) throw new Error('"Edit date" button not found');

    calBtn.scrollIntoView({ behavior: 'smooth', block: 'center' });
    await sleep(250);
    calBtn.click();

    const dialog = await waitFor('[role="dialog"]', document, 6000);
    await sleep(400);

    if (setToNull) {
      // Click the "Set to NULL" button
      const nullBtn = Array.from(dialog.querySelectorAll('button[type="button"]'))
        .find(b => b.textContent.trim() === 'Set to NULL');
      if (!nullBtn) throw new Error('"Set to NULL" button not found in dialog');
      nullBtn.click();
      await sleep(250);
    } else {
      // Navigate calendar to target month, then click the day
      await navToMonth(dialog, date.year, date.month);

      const iso  = date.year + '-' + String(date.month).padStart(2,'0') + '-' + String(date.day).padStart(2,'0');
      const cell = dialog.querySelector('td[data-day="' + iso + '"]');
      if (!cell)                          throw new Error('Date cell not found: ' + iso);
      if (cell.dataset.disabled === 'true') throw new Error('Date is disabled: ' + iso);
      const dayBtn = cell.querySelector('button');
      if (!dayBtn) throw new Error('Day button missing for: ' + iso);
      dayBtn.click();
      await sleep(300);
    }

    // Fill processor name in confirmation input
    const input = dialog.querySelector('#entity-name') ||
                  dialog.querySelector('input[type="text"]');
    if (!input) throw new Error('Name confirmation input not found');
    setVal(input, name);
    await sleep(150);

    // Submit
    const saveBtn = dialog.querySelector('button[type="submit"]');
    if (!saveBtn) throw new Error('Save button not found');
    saveBtn.click();

    // Wait for dialog to disappear
    await waitGone('[role="dialog"]', 8000);
    await sleep(350);
  }

  // ── Main loop ─────────────────────────────────────────
  (async () => {
    let done = 0, failed = 0;

    for (const name of processors) {
      send({ type: 'AUTOMATION_PROGRESS', processorName: name, status: 'running' });
      try {
        await processOne(name);
        done++;
        send({ type: 'AUTOMATION_PROGRESS', processorName: name, status: 'done' });
      } catch (err) {
        failed++;
        send({ type: 'AUTOMATION_PROGRESS', processorName: name, status: 'error', error: err.message });

        // Best-effort dialog cleanup
        const dlg = document.querySelector('[role="dialog"]');
        if (dlg) {
          document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, cancelable: true }));
          await sleep(500);
          const dlg2 = document.querySelector('[role="dialog"]');
          if (dlg2) {
            const reset = dlg2.querySelector('button[type="reset"]');
            if (reset) reset.click();
            await sleep(400);
          }
        }
      }
    }

    send({ type: 'AUTOMATION_DONE', processed: done, failed });
  })();
}

// ── Boot ─────────────────────────────────────────────────
init();
