(function () {
  // Convert snake_case or camelCase key to a human-readable name.
  // e.g. "accounts_28d"                   -> "Accounts 28d"
  // e.g. "accounts_pct_change_28d"        -> "Accounts % Change 28d"
  // e.g. "mdf_claims_dollars_28d"         -> "Mdf Claims $ 28d"
  // e.g. "businessPlans28d"               -> "Business Plans 28d"
  function formatKey(key) {
    let s = key;
    // Replace known patterns with placeholders before splitting
    s = s.replace(/_pct_change/gi, '_PCT_CHANGE');
    s = s.replace(/_pct/gi, '_PCT');
    // Replace underscores with spaces
    s = s.replace(/_/g, ' ');
    // Split camelCase
    s = s.replace(/([a-z])([A-Z])/g, '$1 $2');
    // Title-case each word (lowercase the tail so PCT → Pct, CHANGE → Change)
    s = s.split(/\s+/)
      .filter(w => w.length > 0)
      .map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
      .join(' ');
    // Swap placeholders for symbols
    s = s.replace(/Pct Change/g, '% Change');
    s = s.replace(/Pct/g, '%');
    return s.trim();
  }

  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // Wait for a dialog with data-state="open" to appear in the DOM
  function waitForOpenDialog(timeout = 5000) {
    return new Promise((resolve, reject) => {
      const existing = document.querySelector('[role="dialog"][data-state="open"]');
      if (existing) return resolve(existing);

      const observer = new MutationObserver(() => {
        const found = document.querySelector('[role="dialog"][data-state="open"]');
        if (found) {
          observer.disconnect();
          resolve(found);
        }
      });
      observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['data-state'],
      });
      setTimeout(() => {
        observer.disconnect();
        reject(new Error('Timed out waiting for dialog to open'));
      }, timeout);
    });
  }

  // Wait for all open dialogs to close/disappear
  function waitForDialogClosed(timeout = 5000) {
    return new Promise((resolve) => {
      function isGone() {
        const dialogs = document.querySelectorAll('[role="dialog"]');
        return (
          dialogs.length === 0 ||
          Array.from(dialogs).every(d => d.getAttribute('data-state') !== 'open')
        );
      }

      if (isGone()) return resolve();

      const observer = new MutationObserver(() => {
        if (isGone()) {
          observer.disconnect();
          resolve();
        }
      });
      observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['data-state'],
      });
      // Don't reject on timeout — just move on to avoid getting stuck
      setTimeout(() => {
        observer.disconnect();
        resolve();
      }, timeout);
    });
  }

  // Update a React-controlled input by bypassing React's synthetic event system
  function setReactInputValue(input, value) {
    const nativeSetter = Object.getOwnPropertyDescriptor(
      window.HTMLInputElement.prototype,
      'value'
    ).set;
    nativeSetter.call(input, value);
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }

  // Extract all metric keys from the table (just strings — no DOM refs stored).
  function collectKeys() {
    const keys = [];
    document.querySelectorAll('table tbody tr').forEach(row => {
      const keySpan = row.querySelector('td:first-child .body-sm');
      if (!keySpan) return;
      const key = keySpan.textContent.replace(/Key:\s*/i, '').trim();
      if (key) keys.push(key);
    });
    return keys;
  }

  // Process a single metric by key. Re-finds the edit button fresh each call
  // so stale DOM refs after React re-renders aren't a problem.
  async function processKey(key, settings, onProgress) {
    const formattedName = formatKey(key);

    // Re-find button each time in case the table re-rendered
    const editBtn = document.querySelector(`button[aria-label="Edit ${key}"]`);
    if (!editBtn) {
      onProgress(`  ⚠ Edit button not found for ${key} — skipping`);
      return;
    }

    const row = editBtn.closest('tr');

    // Read the current display name and skip if it already matches
    const keySpan = row && row.querySelector('td:first-child .body-sm');
    if (keySpan) {
      const container = keySpan.parentElement;
      let displayName = '';
      for (const node of container.childNodes) {
        if (node.nodeType === Node.TEXT_NODE && node.textContent.trim()) {
          displayName = node.textContent.trim();
          break;
        }
      }
      if (displayName === formattedName) {
        onProgress(`⏭ Already named: "${formattedName}"`);
        return;
      }
    }

    if (row) {
      row.scrollIntoView({ block: 'center' });
      await sleep(150);
    }

    onProgress(`▶ ${key} → "${formattedName}"`);

    // Enable toggle switches based on popup settings
    if (row) {
      const switches = row.querySelectorAll('button[role="switch"]');
      for (const sw of switches) {
        if (sw.getAttribute('aria-checked') === 'true') continue;
        const label = (sw.getAttribute('aria-label') || '').toLowerCase();
        const isCustomerTable = label.includes('customer table');
        const isKeyMetrics = label.includes('custom metric graph');
        if (isCustomerTable && !settings.enableCustomerTable) continue;
        if (isKeyMetrics && !settings.enableKeyMetrics) continue;
        sw.click();
        await sleep(150);
      }
    }

    // Open the edit dialog
    editBtn.click();

    let dialog;
    try {
      dialog = await waitForOpenDialog(5000);
    } catch {
      onProgress(`  ❌ Dialog didn't open — skipping ${key}`);
      return;
    }

    await sleep(300);

    // Set the name field
    const nameInput = dialog.querySelector('input[name="name"], input#name');
    if (nameInput) {
      nameInput.focus();
      setReactInputValue(nameInput, formattedName);
      await sleep(100);
    } else {
      onProgress(`  ⚠ Name input not found for ${key}`);
    }

    // Click Save
    const saveBtn = dialog.querySelector('button[type="submit"]');
    if (!saveBtn) {
      const closeBtn = dialog.querySelector('[aria-label="Close dialog"]');
      if (closeBtn) closeBtn.click();
      onProgress(`  ❌ No save button for ${key}`);
      await waitForDialogClosed(3000);
      return;
    }

    saveBtn.click();
    await waitForDialogClosed(5000);
    await sleep(300);

    onProgress(`  ✓ "${formattedName}"`);
  }

  // Scroll incrementally through the page to force all lazy-rendered rows into the DOM,
  // then scroll back to the top before we start processing.
  async function scrollToLoadAll(onProgress) {
    onProgress('Scrolling to load all rows…');

    const scroller = document.scrollingElement || document.documentElement;
    const step = Math.max(window.innerHeight * 0.8, 400);

    let lastRowCount = 0;
    let stableRounds = 0;

    while (stableRounds < 3) {
      scroller.scrollTop += step;
      await sleep(400);

      const currentCount = document.querySelectorAll('table tbody tr').length;
      if (currentCount === lastRowCount) {
        stableRounds++;
      } else {
        stableRounds = 0;
        lastRowCount = currentCount;
      }
    }

    scroller.scrollTop = 0;
    await sleep(300);
    onProgress(`Scroll complete. ${document.querySelectorAll('table tbody tr').length} rows found.`);
  }

  async function runAutomation(settings, onProgress) {
    await scrollToLoadAll(onProgress);

    // Collect keys as plain strings — DOM refs would go stale after each save
    const keys = collectKeys();
    if (keys.length === 0) {
      onProgress('❌ No metric rows found on this page.');
      return;
    }

    onProgress(`Processing ${keys.length} metric(s)…`);

    for (const key of keys) {
      await processKey(key, settings, onProgress);
    }

    onProgress('✅ All done!');
  }

  // Listen for the START message from the popup
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.action === 'START') {
      const settings = {
        enableCustomerTable: msg.enableCustomerTable !== false,
        enableKeyMetrics: msg.enableKeyMetrics !== false,
      };
      runAutomation(settings, text => {
        // Send progress updates back to the popup
        chrome.runtime.sendMessage({ action: 'PROGRESS', text }).catch(() => {
          // Popup may have closed — ignore
        });
      })
        .then(() => sendResponse({ done: true }))
        .catch(err => sendResponse({ error: err.message }));

      return true; // Keep the message channel open for async sendResponse
    }
  });
})();
