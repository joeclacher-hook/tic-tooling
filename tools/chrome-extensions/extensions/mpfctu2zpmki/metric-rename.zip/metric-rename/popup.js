const runBtn = document.getElementById('runBtn');
const log = document.getElementById('log');

function appendLog(text) {
  log.style.display = 'block';
  const div = document.createElement('div');
  div.textContent = text;
  log.appendChild(div);
  log.scrollTop = log.scrollHeight;
}

runBtn.addEventListener('click', async () => {
  runBtn.disabled = true;
  runBtn.textContent = 'Running…';
  log.innerHTML = '';
  log.style.display = 'none';

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  // Listen for progress messages from the content script
  function onMessage(msg) {
    if (msg.action === 'PROGRESS') {
      appendLog(msg.text);
    }
  }
  chrome.runtime.onMessage.addListener(onMessage);

  const enableCustomerTable = document.getElementById('chkCustomerTable').checked;
  const enableKeyMetrics = document.getElementById('chkKeyMetrics').checked;

  try {
    await chrome.tabs.sendMessage(tab.id, { action: 'START', enableCustomerTable, enableKeyMetrics });
  } catch (err) {
    appendLog('❌ Could not connect to page.');
    appendLog('Make sure you are on the metrics page and try reloading it.');
    appendLog('(Error: ' + err.message + ')');
  }

  chrome.runtime.onMessage.removeListener(onMessage);
  runBtn.disabled = false;
  runBtn.textContent = 'Run on this page';
});
